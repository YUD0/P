# INFO ADMIN GAFI <img src="https://emojis.slackmojis.com/emojis/images/1588315024/8823/hyperkitty.gif" width="35px"></i></b></h2>
``` UPIL FACEBOOK  ```
``` RAKA ANDRIAN TARA  ```
``` YAYAN XD  ```
``` NUGRAHA ```
# ================
``` LAURA WIDYA  ```
``` INDAH  ```
``` ERLI  ```
``` NICKY  ```
``` ANISAH  ```
# DOWNLOAD APK TERMUX 

Klick di 👉[SINI](https://f-droid.org/repo/com.termux_117.apk), Untuk Mendownload Nya Buka Aplikasi Ketikan Perintah Dibawah .
```Enjoy My Live ```

```Fowered By Raka Andrian Tara```

```Bahan Coli Kalean```

https://user-images.githubusercontent.com/95204908/212218324-31be72cf-1fe9-4507-8084-4437ff089d1d.mp4

# INSTALL
`````
rm -rf GAFI
pkg update && pkg upgrade
pkg install python git
python -m pip install requests
python -m pip install bs4
python -m pip install futures
python -m pip install rich
git clone https://github.com/Bajingan-Z/GAFI
cd GAFI
git pull
python Gafi_v3.py
